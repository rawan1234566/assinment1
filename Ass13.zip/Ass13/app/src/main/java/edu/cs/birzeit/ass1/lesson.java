package edu.cs.birzeit.ass1;

public class lesson {
    public  title;
    public content;

}
