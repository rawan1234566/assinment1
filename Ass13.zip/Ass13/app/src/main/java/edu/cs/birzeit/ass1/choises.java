package edu.cs.birzeit.ass1;

public class choises {

}
